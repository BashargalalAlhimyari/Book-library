const keyFeaturedBox = "featured_box";
const keyFeaturedNewsBox = "featured_news_box";
