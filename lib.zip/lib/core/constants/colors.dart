import 'package:flutter/material.dart';

// ignore: constant_identifier_names
const PrimaryColor = Color(0xFF100b20);
