class AppAssets {
  static const logo = "assets/images/icons8-books-48.png";
  static const testImage = "assets/images/test_image.jpg";
}
