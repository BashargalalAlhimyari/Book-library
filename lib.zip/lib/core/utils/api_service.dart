import 'dart:io';
import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:connectivity_plus/connectivity_plus.dart';

class ApiService {
  final Dio _dio;
  final String baseUrl = "http://10.102.217.22:3000/api";

  ApiService(this._dio) {
    // Configure Dio with baseUrl
    _dio.options.baseUrl = baseUrl;
  }

  /// GET request
  Future<dynamic> get({required String endpoint}) async {
    var connectivityResult = await Connectivity().checkConnectivity();
    if (connectivityResult == ConnectivityResult.none) {
      print("🚫 No internet connection");
      return null;
    }

    try {

      var response = await _dio.get(endpoint);

      if (response.statusCode == 200) {

        return response.data;
      } else {

        print("❌ Server error: ${response.statusCode}");
        return null;
      }
    } catch (e) {
      print("⚠️ Error: $e");
      return null;
    }
  }

  /// POST request
  Future<dynamic> post({required String endpoint, required Map<String, dynamic> data}) async {
    var connectivityResult = await Connectivity().checkConnectivity();
    if (connectivityResult == ConnectivityResult.none) {
      print("🚫 No internet connection");
      return null;
    }

    try {
      var response = await _dio.post(endpoint, data: data);

      if (response.statusCode == 200 || response.statusCode == 201) {
        return response.data;
      } else {
        print("❌ Server error: ${response.statusCode}");
        return null;
      }
    } catch (e) {
      print("⚠️ Error: $e");
      throw e; // Rethrow to handle in repository
    }
  }
}