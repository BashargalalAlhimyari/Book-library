abstract class Routes{

  static const String homePage = "/homePage";
  static const String detailsPage = "/detailsPage";

}