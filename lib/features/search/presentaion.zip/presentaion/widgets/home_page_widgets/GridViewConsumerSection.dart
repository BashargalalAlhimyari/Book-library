
import 'package:clean_architecture/features/home/presentaion/widgets/home_page_widgets/BuildGridViewCard.dart';
import 'package:flutter/material.dart';

class GridViewConsumerSecion extends StatelessWidget {
  const GridViewConsumerSecion({
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 400,
      child: GridView.builder(
        reverse: true,
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 7),
        shrinkWrap: true,
        itemCount: 20,
        gridDelegate:
            const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 3,
    
              childAspectRatio: 1,
            ),
        itemBuilder: (context, index) => BuildGridViewCard(),
      ),
    );
  }
}
