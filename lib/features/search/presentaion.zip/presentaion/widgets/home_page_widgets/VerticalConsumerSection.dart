import 'package:clean_architecture/features/home/domain/entity/book_entity.dart';
import 'package:clean_architecture/features/home/presentaion/manager/featuredNewsBooksCubit/cubit/news_books_cubit.dart';
import 'package:clean_architecture/features/home/presentaion/widgets/home_page_widgets/BuildVerticalListviewCard.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

// ignore: must_be_immutable
class VerticalConsumerSection extends StatelessWidget {
   VerticalConsumerSection({super.key});

  List<BookEntity> books = [];

  @override
  Widget build(BuildContext context) {
    return BlocConsumer<NewsBooksCubit, NewsBooksState>(
      listener: (context, state) {
        if (state is NewsBooksSuccess) {
                   books = state.books; // استبدال القائمة فوراً (أسرع وأضمن)
        }

        if (state is NewsBooksCubitPaginationFailure) {
          ScaffoldMessenger.of(
            context,
          ).showSnackBar(SnackBar(content: Text(state.errMessage)));
        }
      },
      builder: (context, state) {
        if (state is NewsBooksSuccess ||
            state is NewsBooksCubitPaginationLoading ||
            state is NewsBooksCubitPaginationFailure) {
          return BuildVerticalListviewCard(books: books);
        } else if (state is NewsBooksFailure) {
          return Center(
            child: Icon(Icons.error, size: 50, color: Colors.yellow),
          );
        } else {
          return const Center(
            child: CircularProgressIndicator(color: Colors.amber),
          );
        }
      },
    );
  }
}
