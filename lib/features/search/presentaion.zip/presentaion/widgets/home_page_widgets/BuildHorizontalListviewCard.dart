import 'package:cached_network_image/cached_network_image.dart';
import 'package:clean_architecture/core/constants/assets.dart';
import 'package:clean_architecture/core/routes/paths_routes.dart';
import 'package:clean_architecture/core/theme/styles.dart';
import 'package:clean_architecture/features/home/domain/entity/book_entity.dart';
import 'package:clean_architecture/features/home/presentaion/manager/featuredBooksCubit/books_cubit.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:go_router/go_router.dart';

class BuildHorizontalListviewCard extends StatefulWidget {
  const BuildHorizontalListviewCard({super.key, required this.books});
  final List<BookEntity> books;

  @override
  State<BuildHorizontalListviewCard> createState() => _BuildHorizontalListviewCardState();
}

class _BuildHorizontalListviewCardState extends State<BuildHorizontalListviewCard> {
  late ScrollController scrollController;

  @override
  void initState() {
    super.initState();
    scrollController = ScrollController();
    scrollController.addListener(_scrollListener);
  }

  @override
  void dispose() {
    scrollController.dispose(); // ⚠️ لا تنس إغلاق الكونترولر لتجنب تسريب الذاكرة
    super.dispose();
  }

  void _scrollListener() {
    // حساب المواقع
    var currentPosition = scrollController.position.pixels;
    var maxPosition = scrollController.position.maxScrollExtent;

    // إذا وصلنا لـ 70% من القائمة
    if (currentPosition >= 0.7 * maxPosition) {
      // ✅ نكتفي بمناداة الكيوبت فقط
      // الكيوبت هو من يملك شرط if (_isLoading) return; فلا داعي لكتابته هنا
      context.read<BooksCubitDartCubit>().fetchFeatureBooks();
    }
  }

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: MediaQuery.of(context).size.height * 0.3,
      child: ListView.builder(
        controller: scrollController,
        scrollDirection: Axis.horizontal,
        // ✅ حماية إضافية من الـ null
        itemCount: widget.books.length, 
        itemBuilder: (context, index) {
          return BookCard(book: widget.books[index]);
        },
      ),
    );
  }
}

// ==========================================
// تم فصل الـ Widget وتحسينها
// ==========================================
class BookCard extends StatelessWidget {
  const BookCard({super.key, required this.book});

  final BookEntity book; // ✅ نمرر الكتاب فقط

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: MediaQuery.of(context).size.width * 0.4,
      child: Column(
        children: [
          AspectRatio(
            aspectRatio: 2.9 / 4,
            child: InkWell(
              onTap: () {
                GoRouter.of(context).push(Routes.detailsPage, extra: book);
              },
              child: Container(
                margin: const EdgeInsets.symmetric(horizontal: 5),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(16),
                  child: CachedNetworkImage(
                    imageUrl: (book.images?.isNotEmpty ?? false)
                        ? book.images![0]
                        : AppAssets.testImage, // صورة افتراضية
                    fit: BoxFit.fill,
                    // ✅ إضافة loading وكود خطأ لتحسين تجربة المستخدم
                    placeholder: (context, url) => const Center(child: CircularProgressIndicator()),
                    errorWidget: (context, url, error) => const Icon(Icons.error),
                  ),
                ),
              ),
            ),
          ),
          const SizedBox(height: 7),
          // ✅ عرض اسم المؤلف الحقيقي بدلاً من الاسم الثابت
          Text(
            book.authors?.first ?? "Unknown Author", 
            style: Styles.style14(context),
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
          ),
        ],
      ),
    );
  }
}