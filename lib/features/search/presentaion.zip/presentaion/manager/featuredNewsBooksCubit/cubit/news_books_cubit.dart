import 'package:bloc/bloc.dart';
import 'package:clean_architecture/core/constants/app_constants.dart';
import 'package:clean_architecture/features/home/domain/entity/book_entity.dart';
import 'package:clean_architecture/features/home/domain/user_cases/fetch_newest_use_case.dart';
import 'package:meta/meta.dart';

part 'news_books_state.dart';

class NewsBooksCubit extends Cubit<NewsBooksState> {
  NewsBooksCubit(this.fetchNewestUseCase) : super(NewsBooksInitial());

  final FetchNewestUseCase fetchNewestUseCase;

  // 1. المتغيرات الداخلية (State Management)
  int _nextPage = 0; // نبدأ من 0 كما اتفقنا
  bool _isLoading = false;
  final List<BookEntity> _allBooks = []; // القائمة التراكمية

  Future<void> fetchNewsBooks() async {
    // حماية من التكرار
    if (_isLoading) return;
    _isLoading = true;

    // تحديد نوع التحميل
    if (_nextPage == 0) {
      emit(NewsBooksLoading());
    } else {
      emit(NewsBooksCubitPaginationLoading());
    }

    // استدعاء اليوزكيس بالصفحة الحالية
    var result = await fetchNewestUseCase.call(_nextPage);

    result.fold(
      (failure) {
        _isLoading = false;
        if (_nextPage == 0) {
          emit(NewsBooksFailure(errMessage: failure.message));
        } else {
          emit(NewsBooksCubitPaginationFailure(errMessage: failure.message));
        }
      },
      (books) {
        _isLoading = false;

        // التحقق من نهاية البيانات
        if (books.isEmpty) return;

        // 2. دمج البيانات (القديم + الجديد) 🌟 هذا هو السطر الأهم
        _allBooks.addAll(books);
        
        // زيادة الصفحة للمرة القادمة
        _nextPage++; 

        // إرسال القائمة الكاملة للواجهة
        emit(NewsBooksSuccess(books: List.from(_allBooks)));
      },
    );
  }
}