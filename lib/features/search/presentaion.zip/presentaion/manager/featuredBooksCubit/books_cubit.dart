import 'package:bloc/bloc.dart';
import 'package:clean_architecture/core/constants/app_constants.dart';
import 'package:clean_architecture/features/home/domain/entity/book_entity.dart';
import 'package:clean_architecture/features/home/domain/user_cases/fetch_books_use_case.dart';
import 'package:meta/meta.dart';

part 'books_state.dart';

class BooksCubitDartCubit extends Cubit<BooksCubitDartState> {
  final FetchBooksUseCase fetchBooksUseCase;

  BooksCubitDartCubit(this.fetchBooksUseCase) : super(BooksCubitDartInitial());

  int _nextPage = 1; 
  bool _isLoading = false; 
  final List<BookEntity> _allBooks = [];

  Future<void> fetchFeatureBooks() async {
    if (_isLoading) return; 
    _isLoading = true;

    if (_nextPage == 1) {

      emit(BooksCubitDartLoading()); 
    } else {
      
      emit(BooksCubitPaginationLoading()); 
    }

    var result = await fetchBooksUseCase.call(_nextPage);

    result.fold(

      (failure) {
        print(" Failure in BooksCubitDartCubit: ${failure.message} ");
        print("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% _nextPage value: $_nextPage ");
        _isLoading = false; // ✅ مهم جداً لإيقاف اللودنج والسماح بالمحاولة مجدداً
        
        if (_nextPage == 1) {
          emit(BooksCubitDartFailure(errMessage: failure.message));
        } else {
          emit(BooksCubitPaginationFailure(errMessage: failure.message));
        }
      },
      (books) {
        _isLoading = false;
        
        // 🛑 التعديل هنا: (Stop Condition)
        // إذا كانت القائمة فارغة، هذا يعني وصلنا للنهاية، لا تزد الصفحة ولا تحدث الـ UI
        if (books.isEmpty) {
            return; 
        }

        // زيادة الصفحة فقط إذا وجدنا بيانات
        _nextPage++; 
        
        _allBooks.addAll(books);
        
        emit(BooksCubitDartSuccess(books: List.from(_allBooks)));
      },
    );
  }
}