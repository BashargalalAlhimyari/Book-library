import 'package:clean_architecture/core/common/type_def/typesdef.dart';
import 'package:clean_architecture/core/constants/app_constants.dart';
import 'package:clean_architecture/core/utils/hive/save_books.dart';
import 'package:clean_architecture/features/home/domain/entity/book_entity.dart';
import 'package:hive/hive.dart';

abstract class HomeLocalDataSource {
  // دوال القراءة (موجودة لديك)
  List<BookEntity> fetchBooks({int pageNumber = 0});
  List<BookEntity> fetchNewsBooks({int pageNumber = 0});

  // ✅ دوال الحفظ (يجب إضافتها ليختفي الخطأ في الريبو)
  Future<void> cacheBooks(List<BookEntity> books);
  Future<void> cacheNewsBooks(List<BookEntity> books);
}

class HomeLocalDataSourceImpl extends HomeLocalDataSource {
  @override
  List<BookEntity> fetchBooks({int pageNumber = 0}) {
    return _getPaginatedData(AppConstants.boxFeaturedBooks, pageNumber);
  }

  @override
  List<BookEntity> fetchNewsBooks({int pageNumber = 0}) {
    return _getPaginatedData(AppConstants.boxFeaturedNewsBox, pageNumber);
  }

  // ✅ تنفيذ دالة حفظ الكتب المميزة
  @override
  Future<void> cacheBooks(List<BookEntity> books) async {
    // saveBooks دالة خارجية قمت باستيرادها، نستخدم await لضمان الحفظ
     saveBooks(books, AppConstants.boxFeaturedBooks);
  }

  // ✅ تنفيذ دالة حفظ الكتب الجديدة
  @override
  Future<void> cacheNewsBooks(List<BookEntity> books) async {
     saveBooks(books, AppConstants.boxFeaturedNewsBox);
  }

  // دالة المساعدة (ممتازة، اتركها كما هي)
  List<BookEntity> _getPaginatedData(String boxName, int pageNumber) {
    if (!Hive.isBoxOpen(boxName)) {
      return [];
    }

    var box = Hive.box<BookEntity>(boxName);

    final int limit = AppConstants.itemsPerPage;

    int startIndex = pageNumber * limit;
    int endIndex = startIndex + limit;

    if (startIndex >= box.length) {
      return [];
    }

    if (endIndex > box.length) {
      endIndex = box.length;
    }

    return box.values.toList().sublist(startIndex, endIndex);
  }
}