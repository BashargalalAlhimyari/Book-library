import 'package:clean_architecture/features/home/domain/entity/book_entity.dart';
import 'package:clean_architecture/features/home/presentaion/presentaion/manager/featuredBooksCubit/books_cubit.dart';
import 'package:clean_architecture/features/home/presentaion/presentaion/widgets/home_page_widgets/BuildHorizontalListviewCard.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

// 1. تصحيح الاسم
// ignore: must_be_immutable
class HorizontalConsumerSection extends StatelessWidget {
  HorizontalConsumerSection({super.key});

  // سنحتفظ بالقائمة هنا فقط لأن حالات التحميل (PaginationLoading)
  List<BookEntity> books = [];

  @override
  Widget build(BuildContext context) {
    return BlocConsumer<BooksCubitDartCubit, BooksCubitDartState>(
      listener: (context, state) {
        if (state is BooksCubitDartSuccess) {
          for (var book in state.books) {
            if (!books.any(
              (existingBook) => existingBook.bookId == book.bookId,
            )) {
              books.add(book);
            }
          
          }
        }

        // معالجة أخطاء الصفحة التالية (Toast/SnackBar)
        if (state is BooksCubitPaginationFailure) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text(state.errMessage),
              backgroundColor: Colors.red,
              duration: const Duration(seconds: 3),
            ),
          );
        }
      },
      builder: (context, state) {
        // 1. حالة النجاح أو تحميل الصفحة التالية (نعرض القائمة الموجودة)
        if (state is BooksCubitDartSuccess ||
            state is BooksCubitPaginationLoading ||
            state is BooksCubitPaginationFailure) {
          return BuildHorizontalListviewCard(books: books);
        }
        // 2. حالة الفشل التام (عند فتح التطبيق)
        else if (state is BooksCubitDartFailure) {
          return Center(
            child: Icon(Icons.error, size: 50, color: Colors.yellow),
          );
        }
        // 3. حالة التحميل الأولية (فقط في البداية)
        else {
          return const Center(
            child: CircularProgressIndicator(color: Colors.amber),
          );
        }
      },
    );
  }
}
