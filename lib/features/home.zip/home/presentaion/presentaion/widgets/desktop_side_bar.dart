import 'package:clean_architecture/core/theme/styles.dart';
import 'package:clean_architecture/features/home/presentaion/presentaion/widgets/home_page_widgets/VerticalConsumerSection.dart';
import 'package:flutter/material.dart';

class DesktopSideBar extends StatelessWidget {
  const DesktopSideBar({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 300,
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Theme.of(context).cardColor,
        border: Border(
          left: BorderSide(
            color: Colors.grey.withOpacity(0.2),
            width: 1,
          ),
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            "مقترحات لك",
            style: Styles.textStyle18,
          ),
          const SizedBox(height: 20),
          Expanded(
            child: SingleChildScrollView(
              child: VerticalConsumerSection(),
            ),
          ),
        ],
      ),
    );
  }
}
