import 'package:clean_architecture/features/home/presentaion/presentaion/widgets/layouts/desktop_layout.dart';
import 'package:clean_architecture/features/home/presentaion/presentaion/widgets/layouts/mobile_layout.dart';
import 'package:clean_architecture/features/home/presentaion/presentaion/widgets/layouts/tablet_layout.dart';
import 'package:flutter/material.dart';

class HomeViewBody extends StatelessWidget {
  final ScrollController? scrollController;

  const HomeViewBody({super.key, this.scrollController});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 12),
      child: LayoutBuilder(
        builder: (context, constraints) {
          if (constraints.maxWidth < 900) {
            return MobileLayout(scrollController: scrollController);
          } else if (constraints.maxWidth < 900) {
            return TabletLayout(scrollController: scrollController);
          } else {
            return DesktopLayout(scrollController: scrollController);
          }
        },
      ),
    );
  }
}
