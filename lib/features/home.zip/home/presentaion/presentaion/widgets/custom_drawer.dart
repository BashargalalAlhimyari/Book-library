import 'package:clean_architecture/core/theme/colors.dart';
import 'package:clean_architecture/core/theme/styles.dart';
import 'package:flutter/material.dart';

class CustomDrawer extends StatelessWidget {
  const CustomDrawer({super.key});

  @override
  Widget build(BuildContext context) {
    return Drawer(
      backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      elevation: 0,
      child: Column(
        children: [
          const DrawerHeader(
            child: Icon(
              Icons.menu_book_rounded,
              size: 50,
              color: AppColors.indigo,
            ),
          ),
          _buildDrawerItem(context, icon: Icons.home, title: "Home"),
          _buildDrawerItem(context, icon: Icons.search, title: "Search"),
          _buildDrawerItem(context, icon: Icons.favorite, title: "Favorites"),
          _buildDrawerItem(context, icon: Icons.person, title: "Profile"),
          const Spacer(),
          _buildDrawerItem(context, icon: Icons.settings, title: "Settings"),
          const SizedBox(height: 20),
        ],
      ),
    );
  }

  Widget _buildDrawerItem(BuildContext context, {required IconData icon, required String title}) {
    return ListTile(
      leading: Icon(icon, color: AppColors.indigo),
      title: Text(
        title,
        style: Styles.style12(context),
      ),
      onTap: () {},
    );
  }
}
