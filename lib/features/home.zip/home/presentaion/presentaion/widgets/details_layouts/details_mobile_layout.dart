import 'package:cached_network_image/cached_network_image.dart';
import 'package:clean_architecture/core/theme/colors.dart';
import 'package:clean_architecture/core/theme/styles.dart';
import 'package:clean_architecture/core/widgets/buttons/custom_button.dart';
import 'package:clean_architecture/features/home/domain/entity/book_entity.dart';
import 'package:clean_architecture/features/home/presentaion/presentaion/widgets/home_page_widgets/BuildHorizontalListviewCard.dart';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

class DetailsMobileLayout extends StatelessWidget {
  final BookEntity books;

  const DetailsMobileLayout({super.key, required this.books});

  @override
  Widget build(BuildContext context) {
    List<BookEntity> relatedBooks = List.filled(10, books);
    return CustomScrollView(
      slivers: [
        SliverFillRemaining(
          hasScrollBody: false,
          child: Container(
            margin: const EdgeInsets.symmetric(horizontal: 20),
            child: Column(
              children: [
                const AppBarBookDetails(),
                BookDetailsImage(images: books.images ?? []),
                const SizedBox(height: 20),
                Text(books.title, style: Styles.textStyle30),
                const SizedBox(height: 5),
                Text(books.description ?? "", style: Styles.textStyle14),
                const SizedBox(height: 5),
                Text(
                  "${books.authors}",
                  style: Styles.textStyle18.copyWith(
                    fontStyle: FontStyle.italic,
                  ),
                ),
                const SizedBox(height: 15),
                if (books.categories != null && books.categories!.isNotEmpty)
                  Wrap(
                    spacing: 8.0,
                    children: books.categories!
                        .map((category) => Chip(label: Text(category)))
                        .toList(),
                  ),
                const SizedBox(height: 20),
                const BookButton(),
                const Expanded(child: SizedBox(height: 20)),
                const Align(
                  alignment: Alignment.centerLeft,
                  child: Text(
                    "related books ",
                    textAlign: TextAlign.left,
                    style: Styles.textStyle16,
                  ),
                ),
                const SizedBox(height: 20),
                Container(
                  height: MediaQuery.of(context).size.height * 0.15,
                  margin: const EdgeInsets.only(bottom: 20),
                  child: BuildHorizontalListviewCard(books: relatedBooks),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }
}

class BookButton extends StatelessWidget {
  const BookButton({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 30),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          CustomButton(
            color: Colors.white,
            textColor: Colors.black,
            text: "Buy now",
            onPressed: () {},
            shape: const RoundedRectangleBorder(
              borderRadius: BorderRadius.only(
                topLeft: Radius.circular(10),
                bottomLeft: Radius.circular(10),
              ),
            ),
          ),
          CustomButton(
            color: AppColors.red,
            textColor: Colors.white,
            text: "Add to cart",
            onPressed: () {},
            shape: const RoundedRectangleBorder(
              borderRadius: BorderRadius.only(
                topRight: Radius.circular(10),
                bottomRight: Radius.circular(10),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class BookDetailsImage extends StatelessWidget {
  const BookDetailsImage({super.key, required this.images});
  final List<String> images;
  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: MediaQuery.of(context).size.height * 0.4,
      child: PageView.builder(
        scrollDirection: Axis.horizontal,
        itemCount: images.length,
        itemBuilder: (context, index) => AspectRatio(
          aspectRatio: 3 / 4,
          child: ClipRRect(
            borderRadius: BorderRadius.circular(16),
            child:
                CachedNetworkImage(imageUrl: images[index], fit: BoxFit.fill),
          ),
        ),
      ),
    );
  }
}

class AppBarBookDetails extends StatelessWidget {
  const AppBarBookDetails({super.key});

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Row(
        children: [
          IconButton(
            onPressed: () {
              GoRouter.of(context).pop();
            },
            icon: const Icon(Icons.cancel_outlined, size: 30),
          ),
          const Spacer(),
          IconButton(
            onPressed: () {},
            icon: const Icon(Icons.shopping_cart_outlined, size: 30),
          ),
        ],
      ),
    );
  }
}
