import 'package:clean_architecture/core/theme/styles.dart';
import 'package:clean_architecture/features/home/domain/entity/book_entity.dart';
import 'package:clean_architecture/features/home/presentaion/presentaion/widgets/details_layouts/details_mobile_layout.dart';
import 'package:clean_architecture/features/home/presentaion/presentaion/widgets/home_page_widgets/BuildHorizontalListviewCard.dart';
import 'package:flutter/material.dart';

class DetailsDesktopLayout extends StatelessWidget {
  final BookEntity books;

  const DetailsDesktopLayout({super.key, required this.books});

  @override
  Widget build(BuildContext context) {
    List<BookEntity> relatedBooks = List.filled(10, books);
    return CustomScrollView(
      slivers: [
        SliverFillRemaining(
          hasScrollBody: false,
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 40, vertical: 20),
            child: Column(
              children: [
                const AppBarBookDetails(),
                const SizedBox(height: 20),
                Expanded(
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // Left Side: Image
                      Expanded(
                        flex: 1,
                        child: BookDetailsImage(images: books.images ?? []),
                      ),
                      const SizedBox(width: 40),
                      // Right Side: Details
                      Expanded(
                        flex: 2,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(books.title, style: Styles.textStyle30),
                            const SizedBox(height: 10),
                            Text(
                              "${books.authors}",
                              style: Styles.textStyle18.copyWith(
                                fontStyle: FontStyle.italic,
                                color: Colors.grey,
                              ),
                            ),
                            const SizedBox(height: 20),
                            Text(books.description ?? "", style: Styles.textStyle14),
                            const SizedBox(height: 20),
                            if (books.categories != null &&
                                books.categories!.isNotEmpty)
                              Wrap(
                                spacing: 8.0,
                                children: books.categories!
                                    .map((category) => Chip(label: Text(category)))
                                    .toList(),
                              ),
                            const SizedBox(height: 40),
                            const BookButton(),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 40),
                const Align(
                  alignment: Alignment.centerLeft,
                  child: Text(
                    "Related Books",
                    textAlign: TextAlign.left,
                    style: Styles.textStyle18,
                  ),
                ),
                const SizedBox(height: 20),
                SizedBox(
                  height: 180,
                  child: BuildHorizontalListviewCard(books: relatedBooks),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }
}
