import 'package:clean_architecture/features/home/presentaion/presentaion/widgets/custom_drawer.dart';
import 'package:clean_architecture/features/home/presentaion/presentaion/widgets/desktop_side_bar.dart';
import 'package:clean_architecture/features/home/presentaion/presentaion/widgets/layouts/tablet_layout.dart';
import 'package:flutter/material.dart';

class DesktopLayout extends StatelessWidget {
  final ScrollController? scrollController;

  const DesktopLayout({super.key, this.scrollController});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        const Expanded(flex: 1, child: CustomDrawer()),
        Expanded(
          flex: 3,
          child: TabletLayout(scrollController: scrollController),
        ),
        const Expanded(flex: 2, child: DesktopSideBar()),
      ],
    );
  }
}
