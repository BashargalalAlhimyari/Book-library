import 'package:clean_architecture/core/theme/styles.dart';
import 'package:clean_architecture/features/home/presentaion/presentaion/widgets/appbar_widget.dart';

import 'package:flutter/material.dart';

import '../home_page_widgets/ContiueReadingCard.dart';
import '../home_page_widgets/GridViewConsumerSection.dart';
import '../home_page_widgets/HorisontalConsumerSection.dart';
import '../home_page_widgets/VerticalConsumerSection.dart';

class TabletLayout extends StatelessWidget {
  final ScrollController? scrollController;

  const TabletLayout({super.key, this.scrollController});

  @override
  Widget build(BuildContext context) {
    return CustomScrollView(
      controller: scrollController,
      physics: const BouncingScrollPhysics(),
      slivers: [
        const SliverToBoxAdapter(child: AppbarSection(isDark: true)),

        // Challenge Card
        SliverPadding(
          padding: EdgeInsets.symmetric(horizontal: MediaQuery.of(context).size.width * 0.1),
          sliver: const SliverToBoxAdapter(child: ContinueReadingCard()),
        ),

        SliverPadding(
          padding: EdgeInsets.symmetric(horizontal: MediaQuery.of(context).size.width * 0.1),
          sliver: const SliverToBoxAdapter(
            child: Padding(
              padding: EdgeInsets.fromLTRB(24, 30, 24, 15),
              child: Text("جاري قراءتها", style: Styles.textStyle18),
            ),
          ),
        ),

        SliverPadding(
          padding: EdgeInsets.symmetric(horizontal: MediaQuery.of(context).size.width * 0.1),
          sliver:  SliverToBoxAdapter(
            child: HorizontalConsumerSection(),
          ),
        ),
        
        SliverPadding(
          padding: EdgeInsets.symmetric(horizontal: MediaQuery.of(context).size.width * 0.1),
          sliver: const SliverToBoxAdapter(
            child: Padding(
              padding: EdgeInsets.fromLTRB(24, 30, 24, 15),
              child: Text("الاكثر قراءة", style: Styles.textStyle18),
            ),
          ),
        ),
        
        SliverPadding(
          padding: EdgeInsets.symmetric(horizontal: MediaQuery.of(context).size.width * 0.1),
          sliver: const SliverToBoxAdapter(child: GridViewConsumerSecion()),
        ),

        SliverPadding(
          padding: EdgeInsets.symmetric(horizontal: MediaQuery.of(context).size.width * 0.1),
          sliver: const SliverToBoxAdapter(
            child: Padding(
              padding: EdgeInsets.fromLTRB(24, 30, 24, 15),
              child: Text("من اجلك ", style: Styles.textStyle18),
            ),
          ),
        ),
        
        SliverPadding(
          padding: EdgeInsets.symmetric(horizontal: MediaQuery.of(context).size.width * 0.1),
          sliver:  SliverToBoxAdapter(child: VerticalConsumerSection()),
        ),
      ],
    );
  }
}
