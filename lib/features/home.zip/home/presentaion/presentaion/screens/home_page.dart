import 'package:clean_architecture/core/theme/styles.dart';
import 'package:clean_architecture/features/home/presentaion/presentaion/manager/featuredNewsBooksCubit/cubit/news_books_cubit.dart';
import 'package:clean_architecture/features/home/presentaion/presentaion/widgets/appbar_widget.dart';
import 'package:clean_architecture/features/home/presentaion/presentaion/widgets/home_page_widgets/ContiueReadingCard.dart';
import 'package:clean_architecture/features/home/presentaion/presentaion/widgets/home_page_widgets/GridViewConsumerSection.dart';
import 'package:clean_architecture/features/home/presentaion/presentaion/widgets/home_page_widgets/HorisontalConsumerSection.dart';
import 'package:clean_architecture/features/home/presentaion/presentaion/widgets/home_page_widgets/VerticalConsumerSection.dart';
import 'package:clean_architecture/features/home/presentaion/presentaion/widgets/home_view_body.dart';
import 'package:clean_architecture/features/home/presentaion/presentaion/widgets/navigationBar.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePage();
}

class _HomePage extends State<HomePage> {
  // 1. تعريف المتحكم
  final ScrollController _scrollController = ScrollController();

  @override
  void initState() {
    super.initState();
    _scrollController.addListener(_onScroll);
  }

  @override
  void dispose() {
    // 4. تنظيف الذاكرة
    _scrollController.dispose();
    super.dispose();
  }

  // 5. دالة الاستماع (نظيفة جداً الآن)
  void _onScroll() {
    final maxScroll = _scrollController.position.maxScrollExtent;
    final currentScroll = _scrollController.position.pixels;

    // عند الوصول لـ 70% من الصفحة
    if (currentScroll >= 0.7 * maxScroll) {
      // نطلب المزيد من الكتب للقائمة العمودية (التي في الأسفل)
      context.read<NewsBooksCubit>().fetchNewsBooks(); 
    }
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      bottomNavigationBar: BuildBottomNav(),

      body:  CustomScrollView(
      controller: _scrollController,
      physics: const BouncingScrollPhysics(),
      slivers: [
        const SliverToBoxAdapter(child: AppbarSection(isDark: true)),

        // Challenge Card
        const SliverPadding(
          padding: EdgeInsets.symmetric(horizontal: 0),
          sliver: SliverToBoxAdapter(child: ContinueReadingCard()),
        ),

        const SliverToBoxAdapter(
          child: Padding(
            padding: EdgeInsets.fromLTRB(24, 30, 24, 15),
            child: Text("جاري قراءتها", style: Styles.textStyle18),
          ),
        ),

         SliverPadding(
          padding: EdgeInsets.symmetric(horizontal: 7),
          sliver: SliverToBoxAdapter(
            child: HorizontalConsumerSection(),
          ),
        ),
        const SliverToBoxAdapter(
          child: Padding(
            padding: EdgeInsets.fromLTRB(24, 30, 24, 15),
            child: Text("الاكثر قراءة", style: Styles.textStyle18),
          ),
        ),
        const SliverToBoxAdapter(child: GridViewConsumerSecion()),
        const SliverToBoxAdapter(
          child: Padding(
            padding: EdgeInsets.fromLTRB(24, 30, 24, 15),
            child: Text("من اجلك ", style: Styles.textStyle18),
          ),
        ),
         SliverPadding(
          padding: EdgeInsets.symmetric(horizontal: 7),
          sliver: SliverToBoxAdapter(child: VerticalConsumerSection()),
        ),
      ],
    )
    );
  }
}
