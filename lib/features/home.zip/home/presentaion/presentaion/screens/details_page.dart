import 'package:clean_architecture/core/widgets/responsive/responsive_layout.dart';
import 'package:clean_architecture/features/home/domain/entity/book_entity.dart';
import 'package:clean_architecture/features/home/presentaion/presentaion/widgets/details_layouts/details_desktop_layout.dart';
import 'package:clean_architecture/features/home/presentaion/presentaion/widgets/details_layouts/details_mobile_layout.dart';
import 'package:flutter/material.dart';

class DetailsPage extends StatelessWidget {
  const DetailsPage({super.key, required this.books});
  final BookEntity books;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: ResponsiveLayout(
        mobileBody: DetailsMobileLayout(books: books),
        tabletBody: DetailsDesktopLayout(books: books), // Tablet can use Desktop layout or a specific one
        desktopBody: DetailsDesktopLayout(books: books),
      ),
    );
  }
}
