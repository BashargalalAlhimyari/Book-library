import 'package:bloc/bloc.dart';
import 'package:clean_architecture/features/home/presentaion/presentaion/manager/navigationCubit/cubit/navigate_cubit.dart';
import 'package:meta/meta.dart';


class NavigateCubit extends Cubit<NavigateState> {
  NavigateCubit() : super(MoveTo(selectedIndex: 0));


  void moveToIndex(int index) {
    emit(MoveTo(selectedIndex: index));
  }
}
