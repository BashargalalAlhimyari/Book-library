enum PasswordStrength { weak, medium, strong }

