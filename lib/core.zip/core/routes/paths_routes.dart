abstract class Routes{

  static const String signUp = '/signUp';
  static const String homePage = "/homePage";
  static const String detailsPage = "/detailsPage";
  static const String loginPage = "/loginPage";
  static const String registerPage = "/registerPage";


}