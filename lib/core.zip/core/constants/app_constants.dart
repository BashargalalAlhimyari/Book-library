abstract class AppConstants {
  static const String appName = 'Bookly';
  static const String appVersion = '1.0.0';
  static const String appDescription = 'A book reading application';

  //localization
  static const String arabicLang = 'ar';
  static const String englishLang = 'en';
  static const String defaultLang = 'en';
  static const List<String> supportedLocales = ['en', 'ar'];

  //Hive box names
  static const String boxAuthTokenName = 'auth_token_box';
  static const String tokenKey = 'auth_token';
  static const String boxFeaturedBooks = "featured_box";
  static const String boxFeaturedNewsBox = "featured_news_box";

  // shared preferences keys
  static const String token = 'TOKEN';
  static const String language = 'LANGUAGE';
  static const String theme = 'THEME';
  static const String onBoarding = 'ON_BOARDING';

  //validation
  static const int minPasswordLength = 6;
  static const int maxPasswordLength = 20;
  static const int minUsernameLength = 3;
  static const int maxUsernameLength = 50;

  //pagination
  static const int itemsPerPage = 10; // limit
  static const int defaultPageNumber = 1;
  static const int maxPageSize = 100;

  // api timeouts
  static const Duration apiConnectTimeout = Duration(seconds: 5);
  static const Duration apiReceiveTimeout = Duration(seconds: 5);
  static const Duration apiSendTimeout = Duration(seconds: 5);
}
