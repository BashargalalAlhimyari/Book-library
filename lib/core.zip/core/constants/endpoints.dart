
const PORT = '3000';
const IP = '10.110.122.22';

class EndPoint {
  static const String apiBaseUrl = 'http://10.110.122.22:3000';
  static const String baseUrl = '$apiBaseUrl/api/v1';
  static const String loginEndpoint = '/auth/login';
  static const String registerEndpoint = '/auth/register';
  static const String booksEndpoint = '/books';
  static const String bookDetailsEndpoint = '/books/{id}';
  static const String uploadsBaseUrl = '$apiBaseUrl/';

  // للدوال التي تحتاج باراميترات، نستخدم دالة ثابتة
  static String bookDetails(int id) => '/books/$id';
}
