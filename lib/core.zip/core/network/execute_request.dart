import 'package:clean_architecture/core/errors/exception.dart'; // تأكد من استيراد كلاس الاكسبشن
import 'package:clean_architecture/core/network/dio_error_handler.dart';
import 'package:dio/dio.dart';

Future<dynamic> performRequest(Future<Response> requestFunc) async {
  try {
                            print("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% _nextPage value: ");

    final response = await requestFunc;

    // التحقق من نجاح الرد
    if ((response.statusCode ?? 0) >= 200 && (response.statusCode ?? 0) < 300) {
       return response.data;
    } else {

       throw ServerException(message: "استجابة غير صحيحة: ${response.statusCode}");
    }

  } on DioException catch (e) {
                        print("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% _nextPage value: ");

    // 1. نستخرج رسالة الخطأ من الهاندلر
    final failure = DioErrorHandler.handle(e);
    
    // 2. 🛑 التعديل الأهم: نرميها كـ Exception وليس Failure
    throw ServerException(message: failure.message); 

  } catch (e) {
                            print("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% _nextPage value: ");

    // التقاط أخطاء الكود (مثل null check operator)
    throw ServerException(message: e.toString());
  }
}